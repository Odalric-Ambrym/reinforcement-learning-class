--- Installation ---

Python >= 3.7.4
Unity >= 2020.3.27f1 (tested on this version only)


1) Clone the ML-Agents repo:
git clone --branch release_19 https://github.com/Unity-Technologies/ml-agents.git


2) Install Unity packages
* Open the Unity Editor
* Window > Package Manager
    > Advanced > Advanced Project Settings > Enable Preview Packages
    > + > Add package from disk > ml-agents/com.unity.ml-agents/package.json
    > + > Add package from disk > ml-agents/com.unity.ml-agents.extensions/package.json


3) Install Python packages (I recommend using a virtual environment)
pip install -r requirements.txt


4) Run the following to check the 3DBall build:
python demo-unity.py

Linux users might need to give permissions:
chmod -R 755 3DBallSingleAgent/3DBallSingleAgent_unix/3DBallSingleAgent.x86_64


5) If the previous works out-of-the-box, congratulations! Otherwise, you may
need to make a build yourself:
* Open the Unity Editor
* Window > Package Manager > ML Agents > Samples > 3D Ball > Import
* Project > Assets > ML-Agents > Examples > 3DBall > Scenes > 3DBall
* The 3D ball environment contains 12 agents. However, the gym-Unity wrapper
only supports single agent environment. Manually delete 11 agents (click + del).
* Edit > Project Settings > Player > Resolution and Presentation
  > Fullscreen Mode: Windowed
  > Default Screen Width: 512
  > Default Screen Height: 256
  > Run In Background: tick---
* File > Build Settings > Add Open Scenes > Build: save under 3DBallSingleAgent.

Remark: for Linux users, the interface may require you to select a file, not a folder.
A quick hack is to create a dummy 3DBallSingleAgent.x86_64 file and select it.


Full guide at :
https://github.com/Unity-Technologies/ml-agents/blob/main/docs/Installation.md
https://github.com/Unity-Technologies/ml-agents/blob/main/docs/Getting-Started.md
