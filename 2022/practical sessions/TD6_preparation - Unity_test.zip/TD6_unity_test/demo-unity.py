from mlagents_envs.environment import UnityEnvironment
from gym_unity.envs import UnityToGymWrapper
import os


def test():
    if os.name == 'posix':
        unity_env = UnityEnvironment('./3DBallSingleAgent/3DBallSingleAgent_unix/3DBallSingleAgent.x86_64')
    elif os.name == 'nt':
        unity_env = UnityEnvironment('./3DBallSingleAgent/3DBallSingleAgent_windows')
    else:
        raise ValueError('Sorry, your OS is not supported :(')

    env = UnityToGymWrapper(unity_env, 0)

    env.reset()
    done = False
    i = 1
    while (i < 60) and (not done):
        print('I: ', i)
        actions = env.action_space
        print(actions)
        a = actions.sample()
        print('a: ', a)
        state, reward, isfinal, info = env.step(a)
        print('S: ', state)
        print('R: ', reward)
        print('F: ', isfinal)
        print('I: ', info)
        done = done or isfinal
        i = i + 1


if __name__ == '__main__':
    test()
