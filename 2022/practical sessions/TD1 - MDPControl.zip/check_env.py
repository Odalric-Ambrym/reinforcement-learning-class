import gym
import numpy as np
import matplotlib
import sys

print("python : ", sys.version)
print("numpy :", np.__version__)
print("gym :", gym.__version__)
print("matplotlib :", matplotlib.__version__)
